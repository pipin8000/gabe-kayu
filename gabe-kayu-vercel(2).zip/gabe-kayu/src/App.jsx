import { useState, useEffect, useCallback, useRef } from "react";

// ─── Constants ────────────────────────────────────────────────────────────────
const WOOD_TYPES = ["Jati","Mahoni","Sonokeling","Merbau","Pinus","Sungkai","Trembesi","Akasia","Bengkirai","Kamper","Lainnya"];
const ROLES = { owner:"Owner", admin:"Admin", staff:"Staff", viewer:"Viewer" };
const ROLE_COLOR = { owner:"#b45309", admin:"#1d4ed8", staff:"#15803d", viewer:"#6b7280" };
const ROLE_BG   = { owner:"#fef3c7", admin:"#dbeafe", staff:"#dcfce7", viewer:"#f3f4f6" };

const DEFAULT_USERS = [
  { id:"u1", name:"Pipin / Gabe", username:"pipin",  password:"gabe2024", role:"owner",  active:true },
  { id:"u2", name:"Admin Gabe",   username:"admin",  password:"admin123", role:"admin",  active:true },
  { id:"u3", name:"Staff Produksi",username:"staff1",password:"staff123", role:"staff",  active:true },
  { id:"u4", name:"Viewer Only",  username:"viewer1",password:"view123",  role:"viewer", active:true },
];
const DEFAULT_PRICES = [
  { id:"dp1",  jenis:"Jati",       harga:8500000,  tanggal:"2025-01-01", by:"pipin", notes:"Harga awal" },
  { id:"dp2",  jenis:"Mahoni",     harga:4500000,  tanggal:"2025-01-01", by:"pipin", notes:"" },
  { id:"dp3",  jenis:"Sonokeling", harga:12000000, tanggal:"2025-01-01", by:"pipin", notes:"" },
  { id:"dp4",  jenis:"Merbau",     harga:7500000,  tanggal:"2025-01-01", by:"pipin", notes:"" },
  { id:"dp5",  jenis:"Pinus",      harga:3000000,  tanggal:"2025-01-01", by:"pipin", notes:"" },
  { id:"dp6",  jenis:"Sungkai",    harga:5000000,  tanggal:"2025-01-01", by:"pipin", notes:"" },
  { id:"dp7",  jenis:"Trembesi",   harga:6000000,  tanggal:"2025-01-01", by:"pipin", notes:"" },
  { id:"dp8",  jenis:"Akasia",     harga:3500000,  tanggal:"2025-01-01", by:"pipin", notes:"" },
  { id:"dp9",  jenis:"Bengkirai",  harga:8000000,  tanggal:"2025-01-01", by:"pipin", notes:"" },
  { id:"dp10", jenis:"Kamper",     harga:4000000,  tanggal:"2025-01-01", by:"pipin", notes:"" },
];

// ─── Privilege ────────────────────────────────────────────────────────────────
const isDapur = (role) => role === "owner" || role === "admin";

// ─── Helpers ──────────────────────────────────────────────────────────────────
const uid   = () => Date.now().toString(36) + Math.random().toString(36).slice(2,6);
const fmt   = n  => Math.round(n).toLocaleString("id-ID");
const today = () => new Date().toISOString().split("T")[0];
const getLatestPrice = (prices, jenis) => {
  const list = prices.filter(p=>p.jenis===jenis).sort((a,b)=>b.tanggal.localeCompare(a.tanggal));
  return list.length ? list[0].harga : 0;
};

// ─── localStorage helpers ─────────────────────────────────────────────────────
function lsGet(key, fallback) {
  try {
    const v = localStorage.getItem(key);
    return v ? JSON.parse(v) : JSON.parse(JSON.stringify(fallback));
  } catch { return JSON.parse(JSON.stringify(fallback)); }
}
function lsSet(key, val) {
  try { localStorage.setItem(key, JSON.stringify(val)); } catch {}
}

// ─── Styles ───────────────────────────────────────────────────────────────────
const S = {
  app:    { fontFamily:"'DM Sans',sans-serif", minHeight:"100vh", background:"#fafaf9", color:"#1c1917" },
  topbar: { display:"flex", alignItems:"center", gap:12, padding:"10px 20px", background:"#fff",
            borderBottom:"1px solid #e7e5e4", flexWrap:"wrap", position:"sticky", top:0, zIndex:10 },
  logo:   { fontWeight:700, fontSize:15, color:"#1c1917", display:"flex", alignItems:"center", gap:6, whiteSpace:"nowrap" },
  tabs:   { display:"flex", gap:2, flex:1, overflowX:"auto" },
  tab:    (on) => ({ background:on?"#f5f5f4":"transparent", border:"none", padding:"7px 14px",
            fontSize:13, color:on?"#1c1917":"#78716c", cursor:"pointer", borderRadius:8,
            fontWeight:on?600:400, display:"flex", alignItems:"center", gap:5, whiteSpace:"nowrap" }),
  userBadge:(role)=>({ fontSize:11, padding:"2px 8px", borderRadius:20,
            background:ROLE_BG[role], color:ROLE_COLOR[role], fontWeight:600 }),
  btn:    (v="primary") => ({
    display:"inline-flex", alignItems:"center", gap:6, cursor:"pointer",
    padding:"9px 18px", borderRadius:8, fontSize:13, fontWeight:600, border:"1px solid",
    ...(v==="primary" ? { background:"#292524", color:"#fff", borderColor:"#292524" }
      : v==="outline" ? { background:"#fff", color:"#44403c", borderColor:"#d6d3d1" }
      :                 { background:"transparent", color:"#78716c", borderColor:"transparent" })
  }),
  btnSm:  { display:"inline-flex", alignItems:"center", gap:4, cursor:"pointer",
            padding:"5px 12px", borderRadius:6, fontSize:12, border:"1px solid #e7e5e4",
            background:"#fff", color:"#57534e" },
  btnDel: { background:"transparent", border:"none", cursor:"pointer", color:"#d6d3d1",
            padding:"4px 6px", borderRadius:4, fontSize:16, lineHeight:1 },
  card:   { background:"#fff", border:"1px solid #e7e5e4", borderRadius:12, padding:"16px 20px", marginBottom:12 },
  slbl:   { fontSize:11, fontWeight:700, color:"#a8a29e", textTransform:"uppercase",
            letterSpacing:"0.07em", marginBottom:10 },
  lbl:    { display:"block", fontSize:12, color:"#78716c", marginBottom:3 },
  input:  { width:"100%", padding:"7px 10px", fontSize:13, background:"#fafaf9",
            border:"1px solid #e7e5e4", borderRadius:7, color:"#1c1917", boxSizing:"border-box", outline:"none" },
  select: { width:"100%", padding:"7px 10px", fontSize:13, background:"#fafaf9",
            border:"1px solid #e7e5e4", borderRadius:7, color:"#1c1917", boxSizing:"border-box", outline:"none" },
  err:    { fontSize:12, color:"#dc2626", marginTop:5 },
  metric: { background:"#f5f5f4", borderRadius:10, padding:"12px 16px" },
  metricLbl: { fontSize:11, color:"#78716c", marginBottom:3 },
  metricVal: { fontSize:20, fontWeight:700, color:"#1c1917" },
  metricUnit:{ fontSize:11, color:"#a8a29e", fontWeight:400 },
  table:  { width:"100%", borderCollapse:"collapse", fontSize:13 },
  th:     { fontSize:11, fontWeight:600, color:"#a8a29e", padding:"6px 10px",
            borderBottom:"1px solid #f5f5f4", textAlign:"left", whiteSpace:"nowrap" },
  td:     { padding:"8px 10px", borderBottom:"1px solid #fafaf9", color:"#1c1917" },
  tdR:    { padding:"8px 10px", borderBottom:"1px solid #fafaf9", color:"#1c1917",
            textAlign:"right", fontVariantNumeric:"tabular-nums" },
  totRow: { background:"#f5f5f4", fontWeight:700 },
  divider:{ height:1, background:"#f5f5f4", margin:"16px 0" },
  tag:    (c) => ({ fontSize:11, padding:"2px 8px", borderRadius:20, fontWeight:600,
            background:c==="green"?"#dcfce7":c==="blue"?"#dbeafe":c==="amber"?"#fef3c7":"#f3f4f6",
            color:      c==="green"?"#15803d":c==="blue"?"#1d4ed8":c==="amber"?"#92400e":"#6b7280" }),
  empty:  { textAlign:"center", padding:"3rem 1rem", color:"#a8a29e", fontSize:14 },
  lockBanner:{ display:"flex", alignItems:"center", gap:8, padding:"10px 14px",
    background:"#fff7ed", border:"1px solid #fed7aa", borderRadius:10, marginBottom:12, fontSize:13, color:"#92400e" },
};

// ─── Login ────────────────────────────────────────────────────────────────────
function LoginScreen({ users, onLogin }) {
  const [user,setUser]=useState(""); const [pass,setPass]=useState(""); const [err,setErr]=useState("");
  const doLogin = () => {
    const u = users.find(x=>x.username===user.trim()&&x.password===pass&&x.active);
    if(!u){setErr("Username atau password salah.");return;}
    onLogin(u);
  };
  return (
    <div style={{minHeight:"100vh",display:"flex",alignItems:"center",justifyContent:"center",
      background:"linear-gradient(135deg,#fafaf9 0%,#f5f5f4 100%)"}}>
      <div style={{background:"#fff",border:"1px solid #e7e5e4",borderRadius:16,
        padding:"2rem 2.25rem",width:340,boxShadow:"0 4px 32px rgba(0,0,0,0.06)"}}>
        <div style={{display:"flex",alignItems:"center",gap:10,marginBottom:4}}>
          <span style={{fontSize:28}}>🪵</span>
          <div>
            <div style={{fontWeight:700,fontSize:16}}>PT. Gabe International</div>
            <div style={{fontSize:12,color:"#78716c"}}>Sistem Kalkulator Material Kayu</div>
          </div>
        </div>
        <div style={S.divider}/>
        <div style={{marginBottom:10}}>
          <label style={S.lbl}>Username</label>
          <input style={S.input} value={user} onChange={e=>setUser(e.target.value)}
            onKeyDown={e=>e.key==="Enter"&&doLogin()} placeholder="username" autoFocus/>
        </div>
        <div style={{marginBottom:10}}>
          <label style={S.lbl}>Password</label>
          <input style={S.input} type="password" value={pass} onChange={e=>setPass(e.target.value)}
            onKeyDown={e=>e.key==="Enter"&&doLogin()} placeholder="password"/>
        </div>
        {err&&<div style={S.err}>{err}</div>}
        <button style={{...S.btn("primary"),width:"100%",justifyContent:"center",marginTop:14}}
          onClick={doLogin}>Masuk →</button>
        <div style={{marginTop:16,padding:"12px 14px",background:"#fafaf9",borderRadius:8,
          fontSize:11,color:"#a8a29e",lineHeight:2.2}}>
          <strong style={{color:"#78716c",display:"block",marginBottom:4}}>Demo akun:</strong>
          <span>pipin / gabe2024 → </span><span style={S.userBadge("owner")}>Owner</span><br/>
          <span>admin / admin123 → </span><span style={S.userBadge("admin")}>Admin</span><br/>
          <span>staff1 / staff123 → </span><span style={S.userBadge("staff")}>Staff</span><br/>
          <span>viewer1 / view123 → </span><span style={S.userBadge("viewer")}>Viewer</span>
        </div>
      </div>
    </div>
  );
}

// ─── Kalkulator ───────────────────────────────────────────────────────────────
function KalkulatorTab({ cu, prices, onSaveHistory }) {
  const dapur = isDapur(cu.role);
  const [nama,setNama]=useState("");
  const [waste,setWaste]=useState(15);
  const [margin,setMargin]=useState(30);
  const [biayaLain,setBiayaLain]=useState(0);
  const [rows,setRows]=useState([{id:uid(),nama:"",p:"",l:"",t:"",qty:1,jenis:"Jati",harga:getLatestPrice(prices,"Jati")}]);
  const [result,setResult]=useState(null);
  const [err,setErr]=useState("");
  const [saved,setSaved]=useState(false);
  const resultRef=useRef(null);

  const addRow=()=>setRows(r=>[...r,{id:uid(),nama:"",p:"",l:"",t:"",qty:1,jenis:"Jati",harga:getLatestPrice(prices,"Jati")}]);
  const delRow=(id)=>{if(rows.length>1)setRows(r=>r.filter(x=>x.id!==id))};
  const updRow=(id,field,val)=>setRows(r=>r.map(x=>x.id===id
    ?{...x,[field]:val,...(field==="jenis"?{harga:getLatestPrice(prices,val)}:{})}:x));

  const hitung=()=>{
    setErr("");setSaved(false);
    if(!nama.trim()){setErr("Nama produk belum diisi.");return;}
    const items=[];
    for(const r of rows){
      const p=parseFloat(r.p),l=parseFloat(r.l),t=parseFloat(r.t),qty=parseInt(r.qty)||1,hr=parseFloat(r.harga)||0;
      if(!p||!l||!t){setErr("Pastikan semua dimensi (P, L, T) sudah diisi.");return;}
      const vb=p*l*t*qty,vk=vb*(1+waste/100),bi=vk*hr;
      items.push({...r,p,l,t,qty,harga:hr,vb,vk,bi});
    }
    const vbT=items.reduce((s,x)=>s+x.vb,0);
    const tbT=items.reduce((s,x)=>s+x.bi,0);
    const vkT=vbT*(1+waste/100);
    const hpp=tbT+biayaLain,pf=hpp*(margin/100),hj=hpp+pf;
    setResult({nama,waste,biayaLain,margin,vb:vbT,vk:vkT,tb:tbT,hpp,pf,hj,items,tanggal:today()});
    setTimeout(()=>resultRef.current?.scrollIntoView({behavior:"smooth",block:"start"}),80);
  };

  const saveHistory=()=>{if(!result)return;onSaveHistory(result);setSaved(true)};

  const colGrid=dapur?"1.6fr 0.6fr 0.6fr 0.6fr 0.5fr 1.2fr 1.2fr 28px":"1.8fr 0.7fr 0.7fr 0.7fr 0.6fr 1.6fr 28px";
  const colHdr=dapur?["Nama komponen","P (m)","L (m)","T (m)","Qty","Jenis Kayu","Rp / m³",""]
                     :["Nama komponen","P (m)","L (m)","T (m)","Qty","Jenis Kayu",""];

  return (
    <div>
      {!dapur&&<div style={S.lockBanner}>🔒 <strong>Mode Staff:</strong>&nbsp;Data harga, biaya & margin bersifat rahasia — hanya tampil volume kayu.</div>}

      <div style={S.card}>
        <div style={S.slbl}>Info Produk</div>
        <div style={{display:"grid",gridTemplateColumns:dapur?"2fr 1fr 1fr 1fr":"2fr 1fr",gap:8}}>
          <div><label style={S.lbl}>Nama produk / furniture</label>
            <input style={S.input} value={nama} onChange={e=>setNama(e.target.value)} placeholder="contoh: Meja Makan 4 Kursi"/>
          </div>
          <div><label style={S.lbl}>Waste / susut (%)</label>
            <input style={S.input} type="number" value={waste} onChange={e=>setWaste(+e.target.value||0)} min="0" max="60"/>
          </div>
          {dapur&&<>
            <div><label style={S.lbl}>Margin keuntungan (%)</label>
              <input style={S.input} type="number" value={margin} onChange={e=>setMargin(+e.target.value||0)} min="0"/>
            </div>
            <div><label style={S.lbl}>Biaya lain-lain (Rp)</label>
              <input style={S.input} type="number" value={biayaLain} onChange={e=>setBiayaLain(+e.target.value||0)} placeholder="upah, finishing..."/>
            </div>
          </>}
        </div>
      </div>

      <div style={S.card}>
        <div style={S.slbl}>Komponen Furniture — ukuran dalam meter (m)</div>
        <div style={{display:"grid",gridTemplateColumns:colGrid,gap:4,marginBottom:4}}>
          {colHdr.map((h,i)=><div key={i} style={{fontSize:11,color:"#a8a29e",padding:"0 4px"}}>{h}</div>)}
        </div>
        {rows.map(r=>(
          <div key={r.id} style={{display:"grid",gridTemplateColumns:colGrid,gap:4,marginBottom:5,alignItems:"center"}}>
            <input style={S.input} value={r.nama} onChange={e=>updRow(r.id,"nama",e.target.value)} placeholder="misal: Top table"/>
            <input style={S.input} type="number" value={r.p} onChange={e=>updRow(r.id,"p",e.target.value)} placeholder="0.00" step="0.01" min="0"/>
            <input style={S.input} type="number" value={r.l} onChange={e=>updRow(r.id,"l",e.target.value)} placeholder="0.00" step="0.01" min="0"/>
            <input style={S.input} type="number" value={r.t} onChange={e=>updRow(r.id,"t",e.target.value)} placeholder="0.000" step="0.001" min="0"/>
            <input style={S.input} type="number" value={r.qty} onChange={e=>updRow(r.id,"qty",e.target.value)} min="1"/>
            <select style={S.select} value={r.jenis} onChange={e=>updRow(r.id,"jenis",e.target.value)}>
              {WOOD_TYPES.map(j=><option key={j} value={j}>{j}</option>)}
            </select>
            {dapur&&<input style={S.input} type="number" value={r.harga} onChange={e=>updRow(r.id,"harga",e.target.value)} step="100000" min="0"/>}
            <button style={S.btnDel} onClick={()=>delRow(r.id)}>✕</button>
          </div>
        ))}
        <button style={{...S.btnSm,marginTop:4}} onClick={addRow}>＋ Tambah komponen</button>
        {err&&<div style={S.err}>{err}</div>}
      </div>

      <button style={{...S.btn("primary"),width:"100%",justifyContent:"center",padding:"12px"}} onClick={hitung}>
        🧮 Hitung Kebutuhan & Biaya
      </button>

      {result&&(
        <div ref={resultRef} style={{marginTop:24}}>
          <div style={S.divider}/>
          <div style={S.slbl}>Hasil — {result.nama}</div>
          <div style={{display:"grid",gridTemplateColumns:dapur?"repeat(4,1fr)":"repeat(2,1fr)",gap:10,marginBottom:14}}>
            <div style={S.metric}><div style={S.metricLbl}>Vol. Bersih</div>
              <div style={S.metricVal}>{result.vb.toFixed(4)}<span style={S.metricUnit}> m³</span></div></div>
            <div style={S.metric}><div style={S.metricLbl}>Vol. + Waste</div>
              <div style={S.metricVal}>{result.vk.toFixed(4)}<span style={S.metricUnit}> m³</span></div></div>
            {dapur&&<>
              <div style={S.metric}><div style={S.metricLbl}>Biaya Bahan</div>
                <div style={{...S.metricVal,fontSize:15}}>Rp {fmt(result.tb)}</div></div>
              <div style={{...S.metric,background:"#f0fdf4",border:"1px solid #bbf7d0"}}>
                <div style={S.metricLbl}>Est. Harga Jual</div>
                <div style={{...S.metricVal,fontSize:15,color:"#15803d"}}>Rp {fmt(result.hj)}</div></div>
            </>}
          </div>

          <div style={S.card}>
            <table style={S.table}>
              <thead><tr>
                {["Komponen","Jenis Kayu","P×L×T (m)","Qty","Vol.Bersih(m³)","Vol.+Waste(m³)",...(dapur?["Biaya(Rp)"]:[])]
                  .map(h=><th key={h} style={S.th}>{h}</th>)}
              </tr></thead>
              <tbody>
                {result.items.map((it,i)=>(
                  <tr key={i}>
                    <td style={S.td}>{it.nama||"-"}</td>
                    <td style={S.td}><span style={S.tag("amber")}>{it.jenis}</span></td>
                    <td style={S.tdR}>{(+it.p).toFixed(2)}×{(+it.l).toFixed(2)}×{(+it.t).toFixed(3)}</td>
                    <td style={S.tdR}>{it.qty}</td>
                    <td style={S.tdR}>{it.vb.toFixed(4)}</td>
                    <td style={S.tdR}>{it.vk.toFixed(4)}</td>
                    {dapur&&<td style={S.tdR}>Rp {fmt(it.bi)}</td>}
                  </tr>
                ))}
                <tr style={S.totRow}>
                  <td style={S.td} colSpan={4}>Total</td>
                  <td style={S.tdR}>{result.vb.toFixed(4)}</td>
                  <td style={S.tdR}>{result.vk.toFixed(4)}</td>
                  {dapur&&<td style={S.tdR}>Rp {fmt(result.tb)}</td>}
                </tr>
              </tbody>
            </table>
          </div>

          {dapur&&(
            <div style={{...S.card,background:"#fafaf9"}}>
              <div style={{display:"grid",gridTemplateColumns:"repeat(4,1fr)",gap:12}}>
                {[["Biaya Bahan Kayu",fmt(result.tb)],["Biaya Lain-lain",fmt(result.biayaLain)],
                  ["Total HPP",fmt(result.hpp)],["Profit ("+result.margin+"%)",fmt(result.pf)]]
                  .map(([l,v])=>(
                    <div key={l}><div style={{...S.lbl,marginBottom:4}}>{l}</div>
                      <div style={{fontSize:15,fontWeight:600}}>Rp {v}</div>
                    </div>
                  ))}
              </div>
              <div style={S.divider}/>
              <div style={{display:"flex",alignItems:"center",gap:12}}>
                <span style={{fontSize:13,color:"#78716c"}}>Estimasi harga jual ke buyer:</span>
                <span style={{fontSize:22,fontWeight:800,color:"#15803d"}}>Rp {fmt(result.hj)}</span>
              </div>
            </div>
          )}

          <div style={{display:"flex",gap:8,marginTop:8,flexWrap:"wrap"}}>
            <button style={S.btnSm} onClick={saveHistory} disabled={saved}>
              {saved?"✅ Tersimpan!":"💾 Simpan ke History"}
            </button>
            <button style={S.btnSm} onClick={()=>window.print()}>🖨️ Print / Export PDF</button>
          </div>
          <div style={{fontSize:12,color:"#a8a29e",marginTop:8,display:"flex",gap:6,alignItems:"center"}}>
            <span style={S.tag("blue")}>Info</span>
            {dapur?"Belum termasuk: ongkir, packaging, PPN.":"Hasil volume untuk produksi. Biaya & harga dikelola Owner/Admin."}
          </div>
        </div>
      )}
    </div>
  );
}

// ─── History ──────────────────────────────────────────────────────────────────
function HistoryTab({ cu, history, onDelete }) {
  const dapur=isDapur(cu.role);
  const [q,setQ]=useState(""); const [expand,setExpand]=useState(null);
  const can=(...r)=>r.includes(cu.role);
  const list=history.filter(h=>!q||h.nama.toLowerCase().includes(q.toLowerCase()));
  const hdrs=dapur?["Tanggal","Produk","Jenis Kayu","HPP (Rp)","Harga Jual (Rp)","Margin","Oleh",""]
                  :["Tanggal","Produk","Jenis Kayu","Vol. Bersih (m³)","Oleh"];
  return (
    <div>
      <div style={{display:"flex",gap:8,marginBottom:14,alignItems:"center"}}>
        <input style={{...S.input,maxWidth:240}} placeholder="Cari nama produk..." value={q} onChange={e=>setQ(e.target.value)}/>
        <span style={{flex:1}}/><button style={S.btnSm} onClick={()=>window.print()}>🖨️ Print</button>
      </div>
      {!dapur&&<div style={S.lockBanner}>🔒 Data biaya, HPP & harga jual tidak ditampilkan — hanya Owner & Admin.</div>}
      {!list.length
        ?<div style={S.empty}>📋 Belum ada history.<br/><span style={{fontSize:12}}>Hitung & simpan dari tab Kalkulator.</span></div>
        :(
          <div style={S.card}>
            <table style={S.table}>
              <thead><tr>{hdrs.map(h=><th key={h} style={S.th}>{h}</th>)}</tr></thead>
              <tbody>
                {list.map(h=>{
                  const jn=[...new Set(h.items.map(i=>i.jenis))].join(", ");
                  return [
                    <tr key={h.id} onClick={()=>setExpand(expand===h.id?null:h.id)}
                      style={{cursor:"pointer",background:expand===h.id?"#fafaf9":""}}>
                      <td style={S.td}>{h.tanggal}</td>
                      <td style={{...S.td,fontWeight:600}}>{h.nama}</td>
                      <td style={{...S.td,fontSize:12,color:"#78716c"}}>{jn}</td>
                      {dapur?<>
                        <td style={S.tdR}>Rp {fmt(h.hpp)}</td>
                        <td style={{...S.tdR,color:"#15803d",fontWeight:600}}>Rp {fmt(h.hj)}</td>
                        <td style={S.tdR}>{h.margin}%</td>
                        <td style={{...S.td,fontSize:12,color:"#78716c"}}>{h.by||"-"}</td>
                        <td style={S.td}>{can("owner","admin")&&
                          <button style={{...S.btnDel,color:"#fca5a5"}}
                            onClick={e=>{e.stopPropagation();onDelete(h.id)}}>🗑</button>}
                        </td>
                      </>:<>
                        <td style={S.tdR}>{h.vb?.toFixed(4)||"-"} m³</td>
                        <td style={{...S.td,fontSize:12,color:"#78716c"}}>{h.by||"-"}</td>
                      </>}
                    </tr>,
                    expand===h.id&&(
                      <tr key={h.id+"-x"} style={{background:"#fafaf9"}}>
                        <td colSpan={hdrs.length} style={{padding:"14px 20px"}}>
                          <div style={{fontSize:12,color:"#78716c",marginBottom:8}}>
                            waste:{h.waste}% | vol.bersih:{h.vb?.toFixed(4)} m³ | +waste:{h.vk?.toFixed(4)} m³
                            {dapur&&<> | biaya lain: Rp {fmt(h.biayaLain||0)}</>}
                          </div>
                          <table style={{...S.table,fontSize:12}}>
                            <thead><tr>
                              {["Komponen","Jenis","Vol.Bersih(m³)","Vol.+Waste(m³)",...(dapur?["Biaya(Rp)"]:[])]
                                .map(c=><th key={c} style={S.th}>{c}</th>)}
                            </tr></thead>
                            <tbody>{h.items.map((it,i)=>(
                              <tr key={i}>
                                <td style={S.td}>{it.nama||"-"}</td>
                                <td style={S.td}><span style={S.tag("amber")}>{it.jenis}</span></td>
                                <td style={S.tdR}>{it.vb?.toFixed(4)}</td>
                                <td style={S.tdR}>{it.vk?.toFixed(4)}</td>
                                {dapur&&<td style={S.tdR}>Rp {fmt(it.bi)}</td>}
                              </tr>
                            ))}</tbody>
                          </table>
                        </td>
                      </tr>
                    )
                  ];
                })}
              </tbody>
            </table>
          </div>
        )}
    </div>
  );
}

// ─── Harga Kayu ───────────────────────────────────────────────────────────────
function HargaTab({ cu, prices, onAddPrice }) {
  const [showForm,setShowForm]=useState(false);
  const [jenis,setJenis]=useState("Jati"); const [harga,setHarga]=useState("");
  const [tgl,setTgl]=useState(today()); const [notes,setNotes]=useState(""); const [err,setErr]=useState("");
  const latestMap={};
  prices.forEach(p=>{if(!latestMap[p.jenis]||p.tanggal>latestMap[p.jenis].tanggal)latestMap[p.jenis]=p;});
  const save=()=>{
    if(!harga||parseFloat(harga)<=0){setErr("Harga harus diisi.");return;}
    onAddPrice({id:uid(),jenis,harga:parseFloat(harga),tanggal:tgl,by:cu.username,notes});
    setHarga("");setNotes("");setErr("");setShowForm(false);
  };
  return (
    <div>
      <div style={{...S.lockBanner,flexDirection:"column",alignItems:"flex-start",gap:4,marginBottom:16}}>
        <div style={{fontWeight:700,fontSize:13}}>🔒 Halaman Rahasia — Hanya Owner & Admin</div>
        <div style={{fontSize:12,color:"#b45309"}}>Data harga kayu per m³ adalah informasi dapur PT. Gabe International.</div>
      </div>
      <div style={S.card}>
        <div style={S.slbl}>Harga Terkini per m³</div>
        <table style={S.table}>
          <thead><tr>{["Jenis Kayu","Harga/m³ (Rp)","Tgl. Update","Oleh","Catatan"].map(h=><th key={h} style={S.th}>{h}</th>)}</tr></thead>
          <tbody>
            {WOOD_TYPES.filter(j=>j!=="Lainnya").map(j=>{
              const p=latestMap[j];
              return <tr key={j}>
                <td style={{...S.td,fontWeight:600}}>{j}</td>
                <td style={S.tdR}>{p?`Rp ${fmt(p.harga)}`:"-"}</td>
                <td style={S.td}>{p?p.tanggal:"-"}</td>
                <td style={{...S.td,fontSize:12,color:"#78716c"}}>{p?p.by:"-"}</td>
                <td style={{...S.td,fontSize:12,color:"#a8a29e"}}>{p?p.notes||"-":"-"}</td>
              </tr>;
            })}
          </tbody>
        </table>
      </div>
      {showForm?(
        <div style={S.card}>
          <div style={S.slbl}>Update Harga Kayu</div>
          <div style={{display:"grid",gridTemplateColumns:"1fr 1fr 1fr",gap:8,marginBottom:8}}>
            <div><label style={S.lbl}>Jenis kayu</label>
              <select style={S.select} value={jenis} onChange={e=>setJenis(e.target.value)}>
                {WOOD_TYPES.filter(j=>j!=="Lainnya").map(j=><option key={j} value={j}>{j}</option>)}
              </select>
            </div>
            <div><label style={S.lbl}>Harga baru / m³ (Rp)</label>
              <input style={S.input} type="number" value={harga} onChange={e=>setHarga(e.target.value)} placeholder="9000000" step="100000"/>
            </div>
            <div><label style={S.lbl}>Tanggal</label>
              <input style={S.input} type="date" value={tgl} onChange={e=>setTgl(e.target.value)}/>
            </div>
          </div>
          <div style={{marginBottom:8}}><label style={S.lbl}>Catatan (opsional)</label>
            <input style={S.input} value={notes} onChange={e=>setNotes(e.target.value)} placeholder="misal: kenaikan harga pasaran"/>
          </div>
          {err&&<div style={S.err}>{err}</div>}
          <div style={{display:"flex",gap:8,marginTop:8}}>
            <button style={S.btn("primary")} onClick={save}>✓ Simpan Harga</button>
            <button style={S.btn("outline")} onClick={()=>setShowForm(false)}>Batal</button>
          </div>
        </div>
      ):(
        <button style={{...S.btnSm,marginBottom:20}} onClick={()=>setShowForm(true)}>＋ Update harga kayu</button>
      )}
      <div style={S.slbl}>Log Historis Harga</div>
      <div style={S.card}>
        <table style={S.table}>
          <thead><tr>{["Tanggal","Jenis Kayu","Harga/m³ (Rp)","Oleh","Catatan"].map(h=><th key={h} style={S.th}>{h}</th>)}</tr></thead>
          <tbody>
            {[...prices].sort((a,b)=>b.tanggal.localeCompare(a.tanggal)).map((p,i)=>(
              <tr key={i}>
                <td style={S.td}>{p.tanggal}</td>
                <td style={{...S.td,fontWeight:600}}>{p.jenis}</td>
                <td style={S.tdR}>Rp {fmt(p.harga)}</td>
                <td style={{...S.td,fontSize:12,color:"#78716c"}}>{p.by}</td>
                <td style={{...S.td,fontSize:12,color:"#a8a29e"}}>{p.notes||"-"}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

// ─── Users ────────────────────────────────────────────────────────────────────
function UsersTab({ cu, users, onSave, onDelete }) {
  const can=(...r)=>r.includes(cu.role);
  const [showForm,setShowForm]=useState(false);
  const [edit,setEdit]=useState(null);
  const [f,setF]=useState({name:"",username:"",password:"",role:"staff",active:true});
  const [err,setErr]=useState("");
  const openAdd=()=>{setEdit(null);setF({name:"",username:"",password:"",role:"staff",active:true});setShowForm(true);setErr("");};
  const openEdit=(u)=>{setEdit(u);setF({...u,password:""});setShowForm(true);setErr("");};
  const save=()=>{
    if(!f.name.trim()||!f.username.trim()){setErr("Nama dan username wajib diisi.");return;}
    if(!edit&&!f.password){setErr("Password wajib untuk user baru.");return;}
    if(!edit&&users.find(x=>x.username===f.username.trim())){setErr("Username sudah digunakan.");return;}
    const data=edit
      ?{...edit,name:f.name,username:f.username.trim(),role:f.role,active:f.active,...(f.password?{password:f.password}:{})}
      :{id:uid(),name:f.name,username:f.username.trim(),password:f.password,role:f.role,active:f.active};
    onSave(data,!!edit);setShowForm(false);setEdit(null);setErr("");
  };
  const MTX=[
    ["Gunakan Kalkulator","✅","✅","✅","❌"],
    ["Input dimensi & jenis kayu","✅","✅","✅","❌"],
    ["Lihat vol. bersih & +waste","✅","✅","✅","❌"],
    ["🔒 Lihat harga kayu / Rp per m³","✅","✅","❌","❌"],
    ["🔒 Lihat biaya bahan & HPP","✅","✅","❌","❌"],
    ["🔒 Lihat margin & profit","✅","✅","❌","❌"],
    ["🔒 Lihat estimasi harga jual","✅","✅","❌","❌"],
    ["Simpan ke history","✅","✅","✅","❌"],
    ["Lihat history (nama & volume)","✅","✅","✅","✅"],
    ["🔒 Lihat history (HPP & harga jual)","✅","✅","❌","❌"],
    ["Hapus history","✅","✅","❌","❌"],
    ["Print / Export PDF","✅","✅","✅","✅"],
    ["🔒 Akses tab Harga Kayu","✅","✅","❌","❌"],
    ["🔒 Update harga kayu","✅","✅","❌","❌"],
    ["Kelola & tambah user","✅","✅","❌","❌"],
    ["Hapus user","✅","❌","❌","❌"],
  ];
  return (
    <div>
      <div style={S.card}>
        <div style={S.slbl}>Daftar Pengguna</div>
        <table style={S.table}>
          <thead><tr>{["Nama","Username","Role","Status",can("owner","admin")?"Aksi":""].map(h=><th key={h} style={S.th}>{h}</th>)}</tr></thead>
          <tbody>
            {users.map(u=>(
              <tr key={u.id}>
                <td style={{...S.td,fontWeight:600}}>{u.name}</td>
                <td style={{...S.td,color:"#78716c"}}>{u.username}</td>
                <td style={S.td}><span style={S.userBadge(u.role)}>{ROLES[u.role]}</span></td>
                <td style={S.td}><span style={S.tag(u.active?"green":"red")}>{u.active?"Aktif":"Nonaktif"}</span></td>
                {can("owner","admin")&&<td style={S.td}>
                  <div style={{display:"flex",gap:4}}>
                    <button style={S.btnSm} onClick={()=>openEdit(u)}>✏️ Edit</button>
                    {can("owner")&&u.id!==cu.id&&<button style={{...S.btnDel,color:"#fca5a5"}} onClick={()=>onDelete(u.id)}>🗑</button>}
                  </div>
                </td>}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      {can("owner","admin")&&!showForm&&<button style={{...S.btnSm,marginBottom:20}} onClick={openAdd}>＋ Tambah user baru</button>}
      {showForm&&(
        <div style={S.card}>
          <div style={S.slbl}>{edit?"Edit User":"Tambah User Baru"}</div>
          <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:8,marginBottom:8}}>
            <div><label style={S.lbl}>Nama lengkap</label><input style={S.input} value={f.name} onChange={e=>setF(x=>({...x,name:e.target.value}))} placeholder="Nama lengkap"/></div>
            <div><label style={S.lbl}>Username</label><input style={S.input} value={f.username} onChange={e=>setF(x=>({...x,username:e.target.value}))} placeholder="username"/></div>
          </div>
          <div style={{display:"grid",gridTemplateColumns:"1fr 1fr 1fr",gap:8}}>
            <div><label style={S.lbl}>Password {edit&&<small style={{color:"#a8a29e"}}>(kosong = tidak ganti)</small>}</label>
              <input style={S.input} type="password" value={f.password} onChange={e=>setF(x=>({...x,password:e.target.value}))} placeholder={edit?"(opsional)":"password baru"}/>
            </div>
            <div><label style={S.lbl}>Role</label>
              <select style={S.select} value={f.role} onChange={e=>setF(x=>({...x,role:e.target.value}))}>
                {Object.entries(ROLES).map(([v,l])=><option key={v} value={v}>{l}</option>)}
              </select>
            </div>
            <div><label style={S.lbl}>Status</label>
              <select style={S.select} value={f.active?"1":"0"} onChange={e=>setF(x=>({...x,active:e.target.value==="1"}))}>
                <option value="1">Aktif</option><option value="0">Nonaktif</option>
              </select>
            </div>
          </div>
          {err&&<div style={S.err}>{err}</div>}
          <div style={{display:"flex",gap:8,marginTop:12}}>
            <button style={S.btn("primary")} onClick={save}>✓ {edit?"Update user":"Tambah user"}</button>
            <button style={S.btn("outline")} onClick={()=>{setShowForm(false);setEdit(null);setErr("")}}>Batal</button>
          </div>
        </div>
      )}
      <div style={{...S.slbl,marginTop:24}}>Privilege Matrix — 🔒 = Data Rahasia Dapur</div>
      <div style={S.card}>
        <table style={{...S.table,fontSize:12}}>
          <thead><tr>
            <th style={S.th}>Fitur</th>
            {["owner","admin","staff","viewer"].map(r=><th key={r} style={{...S.th,textAlign:"center"}}><span style={S.userBadge(r)}>{ROLES[r]}</span></th>)}
          </tr></thead>
          <tbody>
            {MTX.map(([feat,...vals],i)=>(
              <tr key={i} style={{background:feat.startsWith("🔒")?"#fffbeb":""}}>
                <td style={S.td}>{feat}</td>
                {vals.map((v,j)=><td key={j} style={{...S.td,textAlign:"center"}}>{v}</td>)}
              </tr>
            ))}
          </tbody>
        </table>
        <div style={{marginTop:10,fontSize:11,color:"#a8a29e"}}>🔒 = Hanya Owner & Admin yang dapat mengakses.</div>
      </div>
    </div>
  );
}

// ─── Main App ─────────────────────────────────────────────────────────────────
export default function App() {
  const [loaded,setLoaded]=useState(false);
  const [cu,setCu]=useState(null);
  const [tab,setTab]=useState("calc");
  const [users,setUsers]=useState([]);
  const [history,setHistory]=useState([]);
  const [prices,setPrices]=useState([]);

  useEffect(()=>{
    setUsers(lsGet("gabe:users",DEFAULT_USERS));
    setHistory(lsGet("gabe:history",[]));
    setPrices(lsGet("gabe:prices",DEFAULT_PRICES));
    setLoaded(true);
  },[]);

  const can=useCallback((...r)=>cu&&r.includes(cu.role),[cu]);
  const handleLogin=(u)=>{setCu(u);setTab(u.role==="viewer"?"history":"calc");};

  const saveHistory=(res)=>{
    const next=[{...res,id:uid(),by:cu.name},...history];
    setHistory(next);lsSet("gabe:history",next);
  };
  const deleteHistory=(id)=>{
    if(!window.confirm("Hapus history ini?"))return;
    const next=history.filter(h=>h.id!==id);setHistory(next);lsSet("gabe:history",next);
  };
  const addPrice=(p)=>{
    const next=[...prices,p];setPrices(next);lsSet("gabe:prices",next);
  };
  const saveUser=(data,isEdit)=>{
    const next=isEdit?users.map(u=>u.id===data.id?data:u):[...users,data];
    setUsers(next);lsSet("gabe:users",next);
  };
  const deleteUser=(id)=>{
    if(!window.confirm("Hapus user ini?"))return;
    const next=users.filter(u=>u.id!==id);setUsers(next);lsSet("gabe:users",next);
  };

  if(!loaded)return(
    <div style={{...S.app,display:"flex",alignItems:"center",justifyContent:"center",minHeight:"100vh"}}>
      <div style={{textAlign:"center",color:"#a8a29e"}}>
        <div style={{fontSize:36,marginBottom:8}}>🪵</div>
        <div>Memuat sistem PT. Gabe International...</div>
      </div>
    </div>
  );

  if(!cu)return <LoginScreen users={users} onLogin={handleLogin}/>;

  const TABS=[
    ...(can("owner","admin","staff")?[["calc","🧮","Kalkulator"]]:[]),
    ["history","📋","History"],
    ...(can("owner","admin")?[["prices","🔒","Harga Kayu"]]:[]),
    ...(can("owner","admin")?[["users","👥","Users"]]:[]),
  ];

  return (
    <div style={S.app}>
      <div style={S.topbar}>
        <div style={S.logo}>🪵 PT. Gabe International</div>
        <div style={S.tabs}>
          {TABS.map(([id,ic,lb])=>(
            <button key={id} style={S.tab(tab===id)} onClick={()=>setTab(id)}>{ic} {lb}</button>
          ))}
        </div>
        <div style={{display:"flex",alignItems:"center",gap:8,marginLeft:"auto"}}>
          <span style={{fontSize:13,color:"#78716c"}}>{cu.name}</span>
          <span style={S.userBadge(cu.role)}>{ROLES[cu.role]}</span>
          <button style={{...S.btn("ghost"),padding:"5px 10px",fontSize:12}} onClick={()=>setCu(null)}>Logout</button>
        </div>
      </div>
      <div style={{padding:"20px 24px",maxWidth:1100,margin:"0 auto"}}>
        {tab==="calc"    &&can("owner","admin","staff")&&<KalkulatorTab cu={cu} prices={prices} onSaveHistory={saveHistory}/>}
        {tab==="history" &&<HistoryTab cu={cu} history={history} onDelete={deleteHistory}/>}
        {tab==="prices"  &&can("owner","admin")&&<HargaTab cu={cu} prices={prices} onAddPrice={addPrice}/>}
        {tab==="users"   &&can("owner","admin")&&<UsersTab cu={cu} users={users} onSave={saveUser} onDelete={deleteUser}/>}
      </div>
    </div>
  );
}
